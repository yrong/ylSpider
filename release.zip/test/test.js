let str = 'downloadVerify("8754407","211277135")'
let regex = /^downloadVerify\("(\d+)","(\d+)"\)$/
let match = regex.exec(str)
console.log(match)
